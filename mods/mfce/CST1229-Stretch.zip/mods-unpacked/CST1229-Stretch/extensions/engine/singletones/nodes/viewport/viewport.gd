extends "res://engine/singletones/nodes/viewport/viewport.gd"

func _update_view() -> void :
	super();
	if !vp: return
	
	var win_size := DisplayServer.window_get_size();
	container.set_anchors_preset(Control.PRESET_TOP_LEFT);
	container.position = Vector2.ZERO;
	container.scale = Vector2(win_size) / Vector2(vp.size);
	container.size = vp.size;
	center_container.set_anchors_preset(Control.PRESET_TOP_LEFT);
	center_container.position = Vector2.ZERO;
	center_container.scale = container.scale;
	center_container.size = vp.size;
