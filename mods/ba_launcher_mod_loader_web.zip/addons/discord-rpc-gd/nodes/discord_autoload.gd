





extends Node

func _ready() -> void :
    pass

func _process(_delta) -> void :
    DiscordRPC.run_callbacks()
