extends TextureButton



func _ready():
    pass



func _physics_process(delta):
    if button_pressed:
        pivot_offset.y = lerp(pivot_offset.y, -3.0, 0.5)
    elif is_hovered():
        pivot_offset.y = lerp(pivot_offset.y, 1.0, 0.5)
    else:
        pivot_offset.y = lerp(pivot_offset.y, 0.0, 0.5)
