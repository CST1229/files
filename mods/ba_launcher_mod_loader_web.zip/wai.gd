extends Node2D
var dead = false
var velocity = Vector2(0, 0)
var direction

func _ready() -> void :
    $AnimatedSprite2D.animation = str(randi_range(0, 7))
    $AnimatedSprite2D.play()
    if direction == 1:
        position.y = 792
    else:
        position.y = -86

func _physics_process(delta: float) -> void :
    if direction == 1:
        position.y -= 6
    else:
        position.y += 6
    if Input.is_action_just_pressed("click"):
        if $ClickBox.button_pressed:
            if dead == false:
                get_parent().get_node("Kill").play()
                get_parent().get_node("Collect").play()
                dead = true
                velocity.y = -15
                get_parent().score += 1
                get_parent().get_node("Score/AnimationPlayer").play("Bounce")
                velocity.x = 10
    if dead == true:
        position += velocity
        velocity.y += 1.5
