extends "res://Play.gd"

func finish_level():
	if global.server == "https://barfysadventuretest.nfshost.com":
		super();
		return;
	global.debug_mode = true;
	super()
	global.debug_mode = false;
	global.verified = false;
