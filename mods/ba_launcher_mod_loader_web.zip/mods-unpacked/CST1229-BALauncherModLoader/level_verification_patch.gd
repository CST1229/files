extends "res://Play.gd"

func finish_level():
	global.debug_mode = true
	super()
	global.debug_mode = false
	global.verified = false
