extends TextureButton
@export var originalscale: float = 1

func _ready():
	pass

func _physics_process(_delta):
	if !disabled && is_hovered():
		for i in get_parent().get_children():
			if i.z_index == 101:
				i.z_index = 0
		z_index = 101
		scale.x = lerp(scale.x, 1.2 * originalscale, 0.5)
		scale.y = lerp(scale.y, 1.2 * originalscale, 0.3)
		if Input.is_action_pressed("click") && has_focus():
			scale.x = lerp(scale.x, 0.9 * originalscale, 0.5)
			scale.y = lerp(scale.y, 0.9 * originalscale, 0.3)

	else:
		scale.x = lerp(scale.x, 1.0 * originalscale, 0.7)
		scale.y = lerp(scale.y, 1.0 * originalscale, 0.7)
