extends Button

func _ready() -> void:
	pressed.connect(owner.go_back);
