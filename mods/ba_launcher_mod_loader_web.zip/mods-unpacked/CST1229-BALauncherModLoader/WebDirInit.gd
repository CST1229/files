extends Node

# initialize folders because the modloader crashes on web without them
func _init() -> void:
	if OS.has_feature("web"):
		DirAccess.make_dir_recursive_absolute("user://mods/");
		DirAccess.make_dir_recursive_absolute("user://game-mods/");
	DirAccess.make_dir_recursive_absolute("user://logs/");
